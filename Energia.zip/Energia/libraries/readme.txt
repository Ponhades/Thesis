For information on installing libraries, see: http://www.energia.nu/reference/libraries
