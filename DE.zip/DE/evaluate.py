import math
import numpy as np
from sympy import *

# WORKS
def Evaluate1( _n, vpar ) :

	x = vpar[0]
	y = (x-2.0)*(x-5.0) + math.sin(1.5*math.pi*x)
	
	g = y - 5.0 - 2.5*(x - 6.0)

	return( y, g )

# FLOAT ERROR
def Evaluate2( _n, vpar ) :
	x = vpar[0]
	t= symbols("t")
	y = math.e**2*t
	res = integrate( y, t )

	g = y - 5.0
	
	return ( res, g )

# WORKS
def Evaluate3( _n, vpar ) :
	x = vpar[0]
	v = (x-2)*(x-5) + math.sin( 1.5*math.pi*x )
	g= v - 5.0 - 2.5*(x - 6.0)
	return (v, g)

# WORKS
# The same problem as before but now with one constraint:
def Evaluate4( _n, vpar ) :

	x = vpar[0]
	y = (x-2.0)*(x-5.0) + math.sin(1.5*math.pi*x)

	g = y - 5.0 - 2.5*(x - 6.0)

	# The constraint is introduced according the penalization method :
	# 
	c = g
	if g > 0.0 :
		c = 0.0
	return( y + 20.0*c*c, g )

# WORKS
def Evaluate5( _n, vpar ) :
	i=0
	suma = 0.0
	while i<_n:
		v=vpar[i]
		suma += v*v
		i += 1
		g=suma*4

	return (suma , g)

# WORKS
def Evaluate6( _n, vpar ):
	x = vpar[0]
	r = (x-10.0)*(x-10.0) + 10.0 + 2.0 * math.cos( 2.0*x )
	g=r-1

	return (r,g)

#WORKS
# Función Styblinski-Tank
#
# http://benchmarkfcns.xyz/benchmarkfcns/styblinskitankfcn.html
#
def Evaluate7( _n, vpar ) :
	i=0
	suma=0.0
	while i<_n :
		v = vpar[i]
		v2 = v*v
		suma += v2*v2 - 16.0*v2 + 5.0*v
		i += 1
		g=suma + 3

	return( 0.5*suma, g )

# _n :  it is the number of variables 
# vpar : it is the vector with the values for each variable

def EvaluateA( _n, vpar ) :
	'''Time Parameters'''
	dt = 0.005  # Tiempo de muestreo (5ms)
	ti = 0.0  # Tiempo inicial de la simulación (0s)
	tf = 10.0  # Tiempo inicial de la simulación (10s)
	n = int((tf - ti) / dt) + 1  # Número de muestras
	t = np.linspace(ti, tf, n)  # Vector con los intsntes de tiempo (en Matlab 0:0.005:10)
    
	'''Dynamics Parameters'''
	m = 0.5  # Masa del pendulo (kg)
	l = 1.0  # Longitud de la barra del péndulo (m)
	lc = 0.3  # Longitud al centro de masa del péndulo (m)
	b = 0.05  # Coeficiente de fricción viscosa pendulo
	g = 9.81  # Aceleración de la gravedad en la Tierra
	I = 0.006  # Tensor de inercia del péndulo
	
	'''State variables'''
	x = np.zeros((n, 2))
	
	'''Control vector'''
	u = np.zeros((n, 1))
	ise=0

	'''Initial conditions'''
	x[0, 0] = 0  # Initial pendulum position (rad)
	x[0, 1] = 0  # Initial pendulum velocity (rad/s)
	ie_th = 0

	'''State equation'''
	xdot = [0, 0]

	'''Dynamic simulation'''
	for o in range(n - 1) :

		'''Current states'''
		th = x[o, 0]
		th_dot = x[o, 1]
		e_th =np.pi-th
		e_th_dot = 0 - th_dot

		'''Controller'''
		Kp =vpar[0]
		Kd =vpar[1]
		Ki =vpar[2]
		
		print (vpar)
		
		u[o,0]= Kp * e_th + Kd * e_th_dot + Ki * ie_th
		hh = Kp - 3
		
		'''System dynamics'''
		xdot[0] = th_dot
		xdot[1] = (u[o] - m * g * lc * np.sin(th) - b * th_dot) / (m * lc ** 2 + I)
		
		'''Integrate dynamics'''
		x[o + 1, 0] = x[o, 0] + xdot[0] * dt
		x[o + 1, 1] = x[o, 1] + xdot[1] * dt
		ie_th = ie_th + e_th * dt
		ise=ise+(e_th**2)*dt
		
		#ise=ise_next+(e_th**2)*dt
		#iadu=iadu_next+ (abs(u[o]-u[o-1]))*dt
		#lim=limobjetive(ise,iadu)
		#ise_next=lim[0]
		#iadu_next=lim[1]
		#print(u[o,0])
	return (ise,hh)

def Evaluate( _n, vpar ) :
	# Time Parameters
	ti = 0  # Initial time of the simulation
	tf = 10  # Final time of the simulation
	dt = 1e-4  # Sampling time
	n = int((tf-ti)/dt+1)  # Number of samples
	t = np.linspace(ti, tf, n) # 

	# State variables
	qs = np.zeros((n, 3))

	# Initial conditions
	qs[0, 0] = 0 # Initial position q2 (rad)
	qs[0, 1] = 0  # Initial velocity q2p (rad/s)
	qs[0, 2] = 0 # Initial armature current i (A)
	TL = 0 # Torque [N*m]

	# Control vector
	u = np.zeros(n)

	## Parameters
	# Trajectory
	A=np.pi; # Amplitud
	T=10; # Period
	f=1/T; # Frecuency

	# DC Motor
	Ra=9.665 # Armature Resistance [Ohms]
	La=102.44e-3 # Armature Inductance [H]
	km=0.3946 # Motor torque constant [Nm]
	ke=0.4133 # Back-EMF constant [V/rad]
	bo=5.85e-4 # Viscous Friction coefficient (Damping coefficient) [Nms**2]
	Jo=3.45e-4 # Moment of inertia of rotor [Nms**2]
	"""
	Ra = 8.3 # Armature Resistance [Ohms]
	La = 1.51e-3 # Armature Inductance [H]
	km = 0.0879 # Motor torque constant [Nm]
	ke = 0.0879 # Back-EMF constant [V/rad]
	bo = 14.41e-6 # Viscous Friction coefficient (Damping coefficient) [Nms**2]
	Jo = 80.7e-6 # Moment of inertia of rotor [Nms**2]
	"""

	# Integral error
	ieq = 0
	
	#  Integral squared error
	ise = 0

	# Dynamic simulation
	for i in range(n - 1) :
		# Current states
		q = qs[i, 0] # Current state of q position
		qp = qs[i, 1] # Current state of q velocity
		ia = qs[i, 2] # Current state of i current

		# Trajectory
		w=2*np.pi*f*t[i]; # Omega
		wp=2*np.pi*f; # Omega derivative
		qd = A*np.sin(w)
		qpd = A*np.cos(w)*wp

		# Error vector
		eq = qd - q
		eqp = qpd - qp

		# PID Controller
		# First motor
		kp = vpar[0] # Proportional gain
		ki = vpar[1] # Integral gain
		kd = vpar[2] # Derivative gain

		# Second motor
		# kp = 100 # Proportional gain
		# ki = 1 # Integral gain
		# kd = 5 # Derivative gain

		v = kp*eq+kd*eqp+ki*ieq
		u[i] = v
		
		g= kp - 0.1

		# State vector
		x1p = qp
		x2p = (1/Jo)*(km*ia-bo*qp-TL)
		x3p = (1/La)*(u[i]-Ra*ia-ke*qp)

		# Numeric integrations
		qs[i+1, 0] = qs[i, 0] + x1p*dt
		qs[i+1, 1] = qs[i, 1] + x2p*dt
		qs[i+1, 2] = qs[i, 2] + x3p*dt
		ieq = ieq + eq*dt
		ise = ise + (eq**2)*dt

	return (ise, g)





