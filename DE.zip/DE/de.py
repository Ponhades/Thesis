import numpy # Imports the NumPy package
#import evaluate # Imports the Optimization Problem from the file evaluate.py
import evaluate

def Initialize1( self ) : # Defines the function Initialize1 with no arguments
	i = 0 # Initialize i as 0
	while i<self._pop : # While i is lesser than Population size 
		j = 0 # Initialize j as 0
		while j<self._nv : # while j is lesser than Number of variables
			k = numpy.random.random( ) # k is a random number
			v = self.Limits[0][j] + k * self.vrange[j] # v is equal to the fisrt row and j column of Limits + k times jth Range vector
			self.Pop[i][j] = v # ith row and jth column of Population is equal to v
			j += 1 # j as a counter
		i += 1 # i as a counter

def SetParameters1( self, pop, gen, nv, cf, cr ) : # Defines the function SetParameters1 with 5 arguments
	self._pop = pop # Population size
	self._gen = gen # Number of generations
	self._nv  = nv # Number of variables
	self._const  = nv + 1 # Constant is equal to Number of variables + 1
	self._cf = cf # Differences constant
	self._cr = cr # Recombination constant
	self.Pop = numpy.zeros( (pop, nv+2) ) # Population is a zeros matrix of dimention equal to Popultion size X Number of variables + 2
	self.vnew = numpy.zeros( nv+2 ) # New vector is a zeros vector of dimention Number of variables + 2

def SetLimits1( self, vmin, vmax ) : # Defines the function Setlimits with 2 arguments
	n = len( vmin ) # n is the length of the minima vector
	if n != self._nv : # if n is different of Number of variables
		print( "ERROR: minima vector size is different that the number of variables" )

	n = len( vmax ) # n is the length of the maxima vector
	if n != self._nv : # if n is different of Number of variables
		print( "ERROR: maxima vector size is different that the number of variables" )

	self.Limits = numpy.zeros( (2, self._nv) ) # Limits is a zeros matrix of dimention equal to 2 X Number of variables
	self.vrange = numpy.zeros( self._nv ) # Limits is a zeros vector of dimention equal to Number of variables
	i = 0 # Initializae i as 0
	while i < self._nv : # While i is lesser than Number of variables
		self.Limits[0][i] = vmin[i] # The first row of limits is equal to minima vector
		self.Limits[1][i] = vmax[i]	# The second row of limits is equal to maxima vector
		self.vrange[i] = vmax[i] - vmin[i] # Range vector is equal to maxima vector minus minima vector
		i += 1 # i as a counter

def EvaluatePopulation1( self ) : # Defines the function EvalutePopulation1 with no arguments
	i = 0 # Initialize i as 0
	while i<self._pop : # While i is lesser than Population size
		# v is equal to the first value return of the function Evaluate
		# c is equal to the second value return of the function Evaluate
		# evaluate.Evalute - imports the function Evaluate of evaluate.py
		# The arguments of the function evaluate are the Number of variables and the ith Population
		v, c = evaluate.Evaluate( self._nv, self.Pop[i] ) 
		self.Pop[i][self._nv] = v # The ith row and Number of viriables column of Poulation is equal to v
		self.Pop[i][self._const] = c # The ith row and Constant column of Population is equal to c
		i += 1 # i as a counter

def GenerateNewIndividual1( self, indice ) : # Defines the function GenerateNewIndividual1 with one argument
	# Generate three integer random numbers 

	r1 = numpy.random.randint( 0, self._pop-1 ) # r1 is an integer random number higher than 0 and lower than Population size - 1
	r2 = numpy.random.randint( 0, self._pop-1 ) # r2 is an integer random number higher than 0 and lower than Population size - 1
	while r2==r1 : # While r2 is equal to r1
		r2 = numpy.random.randint( 0, self._pop-1 ) # r2 is an integer random number higher thant 0 and lower thant Population size -1 

	r3 = numpy.random.randint( 0, self._pop-1 )
	while r3==r1 or r3==r2 : # While r3 is equal to r1 OR r3 is equal to r2
		r3 = numpy.random.randint( 0, self._pop-1 ) # r2 is an integer random number higher than o and lower thant Population size - 1 


	irand = numpy.random.randint( 0, self._nv ) # irand is an integer random number higher thant 0 and lower than Number of variables

	i = 0 # Initialize i as 0
	# Generate the new individual
	while i < self._nv :
		if numpy.random.random() < self._cr or i==irand :
			d = self._cf*( self.Pop[r1][i] - self.Pop[r2][i] )
			self.vnew[i] = self.Pop[r3][i] + d

			# Checks the limits
			if self.vnew[i] < self.Limits[0][i] :
				n = self.Limits[0][i] + numpy.random.random() * self.vrange[i]
				self.vnew[i] = n
	
			if self.vnew[i] > self.Limits[1][i] :
				n = self.Limits[0][i] + numpy.random.random() * self.vrange[i]
				self.vnew[i] = n
		else :
			self.vnew[i] = self.Pop[indice][i]

		i += 1
	
# Differntial Evolution class
class DE: # Defines the class DE
	def __init__( self ) : # Defines the function __init__ with no arguments
		self._pop = 0   # Population size
		self._gen = 1   # Number of generations
		self._nv = 0    # Number of variables
		self._cf = 0.5  # Diferences constant
		self._cr = 1.0  # Recombination constant

	SetParameters = SetParameters1 # SetParameters is equal to the function SetParameters1
	SetLimits = SetLimits1 # Setlimits is equalto the function SetLimits1
	Initialize =  Initialize1 # Initialize is equal to the function Initialize1
	EvaluatePopulation = EvaluatePopulation1 # EvaluatePopulation is equal to the function EvaluatePopulation1
	GenerateNewIndividual = GenerateNewIndividual1 # GenerateNewInidividual is equal to the function GenerateNewIndividual

	# Function for the evaluation of the new individual
	def EvaluateNewIndividual( self ) : # Defines the function EvaluateNewIndividual with no arguments
		self.vnew[self._nv], self.vnew[self._const] = evaluate.Evaluate( self._nv, self.vnew )
		if self.vnew[self._const] < 0.0 :
			self.vnew[self._nv] = - self.vnew[self._const]

	# Function for the comparison of the new individual
	def CompareNewIndividual( self, indice ) : # Defines the function CompareNewIndividual with one argument
		# Check of both are feasible
		i = self._const
		if self.vnew[i] >=0 and self.Pop[indice][i] >= 0 :
			i = self._nv
			if self.vnew[i] < self.Pop[indice][i] :
				pass
			else :
				return

		elif self.vnew[i] >=0 :
			pass

		elif self.Pop[indice][i] >= 0:
			return

		elif self.vnew[i] > self.Pop[indice][i] :	
			pass

		j = 0
		while j<=self._const :
			self.Pop[indice][j] = self.vnew[j]
			j += 1

	# Function for the print of the best individual
	def PrintBest( self ) : # Defines the function PrintBest with no arguments
		v = self._nv # v is equal to Number of variables
		miminimo = self.Pop[0][v]
		k = 0 # Initialize k as 0
		i = 1 # Initialize i as 1
		while i < self._pop : # While i is lesser than Population size
			if self.Pop[i][v] < miminimo :
				miminimo = self.Pop[i][v] # minimo is equal to the object (vector) Population size
				k = i # k is equal to i
			i += 1 # i as a counter

		i = 0 # Initialize i as 0
		while i <= v : # While i is lesser-equal to v
			print( self.Pop[k][i], end=' ' )
			i += 1 # i as a counter
		print( ) # Prints a line with nothing
		# print self.Pop[k]
