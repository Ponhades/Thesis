import numpy as np
from matplotlib import *
import matplotlib.pyplot as plt

'''Time Parameters'''
dt = 0.005  # Tiempo de muestreo (5ms)
ti = 0.0  # Tiempo inicial de la simulación (0s)
tf = 10.0  # Tiempo inicial de la simulación (10s)
n = int((tf - ti) / dt) + 1  # Número de muestras
t = np.linspace(ti, tf, n)  # Vector con los intsntes de tiempo (en Matlab 0:0.005:10)

'''Dynamics Parameters'''
m = 0.5  # Masa del pendulo (kg)
l = 1.0  # Longitud de la barra del péndulo (m)
lc = 0.3  # Longitud al centro de masa del péndulo (m)
b = 0.05  # Coeficiente de fricción viscosa pendulo
g = 9.81  # Aceleración de la gravedad en la Tierra
I = 0.006  # Tensor de inercia del péndulo

'''State variables'''
x = np.zeros((n, 2))

'''Control vector'''
u = np.zeros((n, 1))
ise=0

'''Initial conditions'''
x[0, 0] = 0  # Initial pendulum position (rad)
x[0, 1] = 0  # Initial pendulum velocity (rad/s)
ie_th = 0

'''State equation'''
xdot = [0, 0]

'''Dynamic simulation'''
for o in range(n - 1) :

    '''Current states'''
    th = x[o, 0]
    th_dot = x[o, 1]
    e_th =np.pi-th
    e_th_dot = 0 - th_dot

    '''Controller'''
    Kp = 9.883891303417208 
    Kd = 0.60486015083856 
    Ki = 2.5541195108239796

    #Kp=9.976260067080595 
    #Kd=0.77012469386664 
    #Ki=0.9296509244923084

    #Kp = 10
    #Kd = 5
    #Ki = 1
    #0.7773519065741162 
    
    u[o,0]= Kp * e_th + Kd * e_th_dot + Ki * ie_th
    #hh = Kp - 3
    
    '''System dynamics'''
    xdot[0] = th_dot
    xdot[1] = (u[o] - m * g * lc * np.sin(th) - b * th_dot) / (m * lc ** 2 + I)
    
    '''Integrate dynamics'''
    x[o + 1, 0] = x[o, 0] + xdot[0] * dt
    x[o + 1, 1] = x[o, 1] + xdot[1] * dt
    ie_th = ie_th + e_th * dt
    ise=ise+(e_th**2)*dt
    
plt.figure(1)
#plt.plot(t, qs[:, 0], '#00AFEF', label=r'$q$ ''Python')
plt.plot(t, x[:, 0], 'r-')

plt.figure(2)
plt.plot(t, x[:, 1],'r-')

plt.show()