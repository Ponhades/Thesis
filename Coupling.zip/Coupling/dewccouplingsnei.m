clear
format long g
%% Informacion del problema
nx = 25; % Numero de variables de diseno
% Restricciones de caja
xmin = [ 2.406072, 1.02e-3, 9.645e-3, 9.645e-3, 6.145472e-6, 4.498988e-6, 0, 0, 0, 0, 0, 0, 0.03, 0.075, 0.054, 0.09954, 0.209874, 0.16287, 0.162, 0.06, 0.15, 0.108, 125.64856e-6, 1093.99758e-6, 510.61948e-6 ]; % Limites inferiores
xmax = [ 3.609108, 1.53e-3, 0.028935, 0.028935, 9.218208e-6, 6.747732e-6, 0.0005, 0.0005, 0.0005, 1-4e-4, 2.8e-4, 2.1e-4, 0.07, 0.175, 0.126, 0.23226, 0.489706, 0.38003, 0.378, 0.14, 0.35, 0.252, 376.94568e-6, 3281.99274e-6, 1531.85844e-6 ]; % Limites superiores

%% Hiperparametros
Np = 20; % Tamano de la poblacion
gmax = 1000; % Numero de generaciones
Cr = 0.5; % Probabilidad de cruce
F = 0.5; % Factor de escala de mutacion

%% Iniciar poblacion
x = xmin + rand( Np, nx ).*( xmax - xmin ); % Poblacion aleatoria
f_x = zeros( Np, 1 ); % Valores de la funcion objetivo
g_x = zeros( Np, 1 ); % Valores de las restricciones

%% Evaluar
for i = 1:Np % Evaluar todos los indivudos en la poblacion inicial
    [f_x( i ), g_x( i )] = fcouplingsnei( x( i, : ) ); % Evaluar el problema de optimizacion
end

%% Ciclo Evolutivo ( DE/rand/1/bin )
for g = 1:gmax % Evaluar todas las generaciones
    fprintf( "G = %d \n", g );
    for i = 1:Np % Evaluar todos los individuos en en la poblacion
        % Seleccion aleatoria de individuos padres
        r1 = randi( Np );
        while r1 == i % r1 != i
            r1 = randi( Np );
        end
        
        r2 = randi( Np );
        while r2 == r1 || r2 == i % r2 != r1 != i
            r2 = randi( Np );
        end
        
        r3 = randi( Np );
        while r3 == r1 || r3 == r2 || r3 == i % r3 != r1 != r2 != i
            r3 = randi( Np );
        end
        
        % Descendiente (Vector de prueba)
        ui = zeros( 1, nx );
        jrand = randi( nx );
        
        % Mutacion y Cruce
        for j = 1:nx
            if rand( ) <= Cr || j == jrand
                % Individuo mutante (DEwC/rand/1/bin)
                ui( j ) = x( r3, j ) + F*( x( r1, j ) - x( r2, j ) );
                % Revision de limites
                if ui( j ) < xmin( j ) || ui( j ) > xmax( j )
                    ui( j ) = xmin( j ) + rand( ) * ( xmax( j ) - xmin( j ) );
                end
            else
                ui( j ) = x( i, j );
            end
        end
        
        % Evaluacion del descendiente (Vector de prueba)
        [f_ui, g_ui] = fcouplingsnei( ui );
        
        % Seleccion entre padre y descendiente (Regla de Debb)
        if g_ui == 0 && g_x( i ) == 0 % Si amabos individuos son factibles
            if f_ui < f_x( i )  % Si el descendiente es mejor remplaza a su padre
                x( i, : ) = ui;
                f_x( i ) = f_ui;
                g_x( i ) = g_ui;
            else
                % El padre sobrevive y el descendiente muere
                %x(i,:) = x(i,:)
                %f_x(i) = f_ui;
                %g_x(i) = g_ui;
            end
        else
            if g_ui > 0 && g_x( i ) == 0 % El padre sobrevive y el descendiente muere
                %x(i,:) = x(i,:)
                %f_x(i) = f_ui;
                %g_x(i) = g_ui;
            else
                if g_ui == 0 && g_x(i) > 0 % El  padre  muere y el descendiente sobrevive
                    x( i, : ) = ui;
                    f_x( i ) = f_ui;
                    g_x( i ) = g_ui;
                else
                    if g_ui < g_x( i ) % El padre muere y el descendiente sobrevive
                        x( i, : ) = ui;
                        f_x( i ) = f_ui;
                        g_x( i ) = g_ui;
                    else
                        % El padre sobrevive y el descendiente muere
                        %x(i,:) = x(i,:)
                        %f_x(i) = f_ui;
                        %g_x(i) = g_ui;
                    end
                end
            end
        end

    % Seleccion
    [~, besti] = min( f_x ); % Selecciona el mejor individuo de la poblacion
    x( besti, : ) % Vector de variables de diseno
    f_x( besti ) % Funcion objetivo
    g_x( besti ) % Restricciones   

    end
end

%% Seleccion
[~, besti] = min( f_x ); % Selecciona el mejor individuo de la poblacion
x( besti, : ) % Vector de variables de diseno
f_x( besti ) % Funcion objetivo
g_x( besti ) % Restricciones

