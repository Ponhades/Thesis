G1 = table( out.u.signals.values );
writetable( G1,'u_couplingsnei.csv' )
G2 = table( out.q2.signals.values );
writetable( G2,'q2_couplingsnei.csv' )
G3 = table( out.q2p.signals.values );
writetable( G3,'q2p_couplingsnei.csv' )