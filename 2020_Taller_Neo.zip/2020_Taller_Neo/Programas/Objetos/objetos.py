import punto

A = punto.Punto( 2, 3 )
A.print()

B = punto.Punto( 1, 2 )
B.print()

C = A + B
C.print()
