function [ISE, con] = fcouplingwrsnei( xpar )
    % Condicion inicial de restricciones
	con = 0;

    % Restricciones - Configuracion Manivela-Balancin
    if xpar( 19 ) - xpar( 20 ) >= 0 % l1 > l2
    else
        con = con + 1;
    end

    if xpar( 19 ) - xpar ( 21 ) >= 0 % l1 > l3
    else
        con = con + 1;
    end
    
    if xpar( 19 ) - xpar( 22 ) >= 0 % l1 > l4
    else
        con = con + 1;
    end
    
    if xpar( 20 ) - xpar( 21 ) <= 0 % l2 < l3
    else
        con = con + 1;
    end
    
    if xpar( 20 ) - xpar( 22 ) <= 0 % l2 < l4
    else
        con = con + 1;
    end
    
    % Restricciones - Ley de Grashoff
    if   xpar( 19 ) + xpar( 20 ) - xpar( 21 ) - xpar( 22 ) <= 0 % l1 + l2 < l3 + l4
    else
        con = con + 1;
    end

    % Restricciones - Simulacion
    if con > 0 % con = 0
        ISE = Inf;
    else
        % Valores medidos
        Vd = table2array( readtable( 'C:\Users\Ponhades\OneDrive\Documents\Tesis\Disenodetallado\MPISODOP\Matlab\Sensor no estimation\Coupling w Reductor\u_couplingwrsnei.csv' ) );
        q2d = table2array( readtable( 'C:\Users\Ponhades\OneDrive\Documents\Tesis\Disenodetallado\MPISODOP\Matlab\Sensor no estimation\Coupling w Reductor\q2_couplingwrsnei.csv' ) );
        q2dp = table2array( readtable( 'C:\Users\Ponhades\OneDrive\Documents\Tesis\Disenodetallado\MPISODOP\Matlab\Sensor no estimation\Coupling w Reductor\q2p_couplingwrsnei.csv' ) );
        
        % Euler (ode1)
	    % Parametros de simulacion
	    ti = 0; % Tiempo inicial de simulacion [s]
	    tf = 10; % Tiempo de final de simulacion [s]  
	    dt = 0.8e-3; % Tiempo de muestreo [s]
	    n = ( ( tf - ti ) / dt ); % Numero de muestras [12,500]
    
	    % Variables de estado
	    q2s = zeros( n , 3 ); % Estados del acoplamiento
	    eq2s = zeros( n,  2 ); % Estados de error del acoplamiento
    
	    % Condiciones iniciales
	    q2s( 1, 1 ) = 0; % Posicion inicial del acoplamiento [rad]
	    q2s( 1, 2 ) = 0; % Velocidad inicial del acoplamiento [rad/s]
	    q2s( 1, 3 ) = 0; % Corriente de armadura inicial [A]
        eq2s( 1, 1 ) = 0; % Error de posicion inicial del acoplamiento
        eq2s( 1, 2 ) = 0; % Error de velocidad inicial del acoplamiento
	    ISE = 0; % Condicion incial de la Integral del Error Cuadrado
    
        % Parametros
        % Sensor de posicion [V]
        Vs = 5; % Tension de alimentacion del sensor
        
        % Gravedad [m/s^2]
	    g = 9.81;
    
        % Vector de diseño
	    % Motor de corriente directa
	    Ra = xpar( 1 ); % Resistencia de armadura [Ω]
	    La = xpar( 2 ); % Inductancia de armadura [H]
	    km = xpar( 3 ); % Constante del momento del motor de CD [N*m/A]
	    ke = xpar( 4 ); % Constante de fuerza contraelectromotriz del motor de CD [V*s/rad]
	    bm = xpar( 5 ); % Coeficiente de friccion viscosa del motor de CD [N*m*s/rad]
	    Jm = xpar( 6 ); % Momento de inercia del rotor del motor de CD [kg*m^2]
        % Mecanismo de cuatro barras
	    % Angulo al centro de masa [rad]
	    qc2 = xpar( 7 ); % Angulo al centro de masa de la manivela
	    qc3 = xpar( 8 ); % Angulo al centro de masa del acoplador
	    qc4 = xpar( 9 ); % Angulo al centro de masa del balancin
        % Coeficiente de friccion viscosa []
        b2 = xpar( 10 ); % Coeficiente de friccion viscosa de la manivela
        b3 = xpar( 11 ); % Coeficiente de friccion viscosa del acoplador
        b4 = xpar( 12 ); % Coeficiente de friccion viscosa del balancin
	    % Longitud al centro de masa [m]
	    lc2 = xpar( 13 ); % Longitud al centro de masa de la manivela
	    lc3 = xpar( 14 ); % Longitud al centro de masa del acoplador
	    lc4 = xpar( 15 ); % Longitud al centro de masas del balancin
	    % Masa [kg]
	    m2 = xpar( 16 ); % Masa de la manivela
	    m3 = xpar( 17 ); % Masa del acoplador
	    m4 = xpar( 18 ); % Masa del balancin
	    % Longitud [m]
	    l1 = xpar( 19 ); % Longitud de la tierra
	    l2 = xpar( 20 ); % Longitud de la manivela
	    l3 = xpar( 21 ); % Longitud del acoplador
	    l4 = xpar( 22 ); % Longitud del balancin
	    % Momento de inercia [kg*m^2]
	    I2 = xpar( 23 ); % Momento de inercia de la manivela
	    I3 = xpar( 24 ); % Momento de inercia del acoplador
	    I4 = xpar( 25 ); % Momento de inercia del balancin
    
	    % Simulacion dinamica
        for i = 1:n
		    % Estados actuales
		    V = Vd( i ); % Estado actual de la senal de control [V]
		    q2 = ( 2*pi*q2d( i ) ) / Vs; % Estado actual de posicion del acoplamiento [rad]
		    q2p = ( 2*pi*q2dp( i ) ) / Vs; % Estado actual de velocidad del acoplamiento [rad/s]
            ia = q2s( i, 3 ); % Estado actual de la corriente de armadura [A]
            
		    % Coeficientes de la ecuacion de Freudenstein
		    k1 = 2*l3*( l2*cos( q2 ) - l1 );
		    k2 = 2*l2*l3*sin( q2 );
		    k3 = l1^2 + l2^2 + l3^2 - l4^2 - 2*l1*l2*cos( q2 );
    
		    % Posicion
		    q3 = 2*atan2( - k2 + sqrt( k1^2 + k2^2 - k3^2 ), k3 - k1 ); % Posicion del acoplador [rad]
		    q4 = atan2( l2*sin( q2 ) + l3*sin( q3 ), - l1 + l2*cos( q2 ) + l3*cos( q3 ) ); % Posicion del balancin [rad]
    
		    % Ecuaciones auxiliares
		    S1 = ( l2*sin( q4 - q2 ) ) / ( l3*sin( q3 - q4 ) );
		    S2 = ( l2*sin( q3 - q2 ) ) / ( l4*sin( q3 - q4 ) );
		    J1 = ( 1 / 2 )*( m2*lc2^2 + I2 + m3*l2^2 );
		    J2 = ( 1 / 2 )*( m3*lc3^2 + I3 );
		    J3 = ( 1 / 2 )*( m4*lc4^2 + I4 );
		    P1 = m3*l2*lc3;
		    C1 = cos( q2 - q3 - qc3 );
            B = b2 + b3 + b4;
            
		    % Ecuaciones auxiliares para el modelo dinamico de cadena cinematica cerrada
		    PS1q2 = - ( l2*cos( q2 - q4 ) ) / ( l3*sin( q3 - q4 ) );
		    PS1q3 = ( l2*sin( q2 - q4 )*cos( q3 - q4 ) ) / ( l3*sin( q3 - q4 )^2 );
		    PS1q4 = - ( l2*sin( q2 - q3 ) ) / ( l3*sin( q3 - q4 )^2 );
		    PS2q2 = - ( l2*cos( q2 - q3 ) ) / ( l4*sin( q3 - q4 ) );
		    PS2q3 = ( l2*sin( q2 - q4 ) ) / ( l4*sin( q3 - q4 )^2 );
		    PS2q4 = - ( l2*sin( q2 - q3 )*cos( q3 - q4 ) ) / ( l4*sin( q3 - q4 )^2 );
		    PC1q2 = - sin( q2 - q3 - qc3 );
		    PC1q3 = sin( q2 - q3 - qc3 );
		    PG1q2 = - m2*g*lc2*cos( q2 + qc2 ) - m3*g*l2*cos( q2 );
		    PG1q3 = - m3*g*lc3*cos( q3 + qc3 );
		    PG1q4 = - m4*g*lc4*cos( q4 + qc4 );
		    DS1 = PS1q2 + PS1q3*S1 + PS1q4*S2;
		    DS2 = PS2q2 + PS2q3*S1 + PS2q4*S2;
		    DC1 = PC1q2 + PC1q3*S1;
		    DG1 = PG1q2 + PG1q3*S1 + PG1q4*S2;
    
		    % Vector de inercia
		    M = 2*( J1 + J2*S1^2 + J3*S2^2 + P1*C1*S1 );
    
		    % Vector de coriolis
		    C = ( 2*J2*S1*DS1 + 2*J3*S2*DS2 + P1*S1*DC1 + P1*C1*DS1 )*( q2p );
            
            % Vector de friccion viscosa
            F = B*q2p;
    
		    % Vector de gravedad
		    G = - DG1;
    
		    % Vector de estados
		    z1p = q2p;
		    z2p = ( 1 / ( M + Jm ) )*( km*ia - C*q2p - bm*q2p - F - G );
		    z3p = ( 1 / La )*( V - Ra*ia - ke*q2p );
    
		    % Integraciones numericas
		    q2s( i + 1, 1 ) = q2s( i, 1 ) + z1p*dt;
		    q2s( i + 1, 2 ) = q2s( i, 2 ) + z2p*dt;
		    q2s( i + 1, 3 ) = q2s( i, 3 ) + z3p*dt;
    
		    % Vector de error	
		    eq2s( i, 1 ) = ( ( 2*pi*q2d( i + 1 ) ) / Vs ) - q2s( i + 1, 1 ); % Error de posicion del acoplamiento [rad]
		    eq2s( i, 2 ) = ( ( 2*pi*q2dp( i + 1 ) ) / Vs ) - q2s( i + 1, 2 ); % Error de velocidad del acoplamiento [rad/s]
    
		    % Funcion objetivo
		    ISE = ISE + ( eq2s( i, 1 )^2 )*dt + ( eq2s( i, 2 )^2 )*dt;
		    
            if ISE ~= ISE
 			    % fprintf( "¡Se indetermino!" )
                ISE = Inf; 
            end
        end
    end
end