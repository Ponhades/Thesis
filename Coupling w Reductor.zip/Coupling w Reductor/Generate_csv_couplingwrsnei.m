G1 = table( out.u.signals.values );
writetable( G1,'u_couplingwrsnei.csv' )
G2 = table( out.q2.signals.values );
writetable( G2,'q2_couplingwrsnei.csv' )
G3 = table( out.q2p.signals.values );
writetable( G3,'q2p_couplingwrsnei.csv' )