import de # Imports the Differential Evolution algorithm from the file de.py

Data = de.DE() # Assigns the data of the class DE to "Data"

# Arguments to SetParameters() :
# Population size
# Number of generations
# Number of variables
# Differences constant
# Recombination constant

# Data.SetParameters( 16, 30, 1, 0.8, 0.6 )
# Data.SetLimits( [0.0], [7.0] )
# Data.SetLimits( [-5.0, -5.0, -5.0, -5.0, -5.0], [5.0, 5.0, 5.0, 5.0, 5.0] )

Data.SetParameters( 16, 100, 1, 0.8, 0.6 ) 
Data.SetLimits( [3.0], [4.0] )
Data.Initialize( ) # Calls the data of Initiaize from class DE with no arguments
Data.EvaluatePopulation( ) # Calls the data of EvaluatePopulation from class DE with no arguments
i=0 # Initialize i as 0
while i<Data._gen : 
	j=0 # Initialize j as 0
	while j<Data._pop :
		Data.GenerateNewIndividual( j ) # Calls the data of GenerateNewIndividual from class DE assigning j as argument
		Data.EvaluateNewIndividual( ) # Calls the data of EvaluateNewIndividual from class DE with no arguments
		# It is compared with the father, if it is better substitute the father
		Data.CompareNewIndividual( j ) # Calls the data of CompareNewIndividual from class DE assigning j as argument
		j += 1 # j as a counter
	i += 1 # i ass a counter

Data.PrintBest( ) # Calls the data of PrintBest from class DE with no arguments
