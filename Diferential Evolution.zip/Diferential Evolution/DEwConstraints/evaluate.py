# Here is defined the objective function

import math
# import sympy import *

# _n :  it is the number of variables 
# vpar : it is the vector with the values for each variable


# The same probleme as before but now with one constraint:
def Evaluate( _n, vpar ) :

	x = vpar[0]
	y = (x-2.0)*(x-5.0) + math.sin(1.5*math.pi*x)
	
	g = y - 5.0 - 2.5*(x - 6.0)

	return( y, g )


# def Evaluate1( _n, vpar ) :
#
#	x = vpar[0]
#	t = symbols("t")
#	y = e**2*t
#	res = integrate( y, t )
#
#	g = y - 5.0
#
#	return ( res, g)
