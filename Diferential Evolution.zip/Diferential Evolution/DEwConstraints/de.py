import numpy # Imports the NumPy package
import evaluate # Imports the Optimization Problem from the file evaluate.py

def Initialize1( self ) : # Defines the function Initialize1 with no arguments
	i = 0 # Initialize i as 0
	while i<self._pop : 
		j = 0 # Initialize j as 0
		while j<self._nv :
			k = numpy.random.random( )
			v = self.Limits[0][j] + k * self.vrange[j]
			self.Pop[i][j] = v
			j += 1 # j as a counter
		i += 1 # i as a counter

def SetParameters1( self, pop, gen, nv, cf, cr ) :
	self._pop = pop # Population size
	self._gen = gen # Number of generations
	self._nv  = nv # Number of variables
	self._const  = nv + 1 # 
	self._cf = cf # Differences constant
	self._cr = cr # Recombination constant
	self.Pop = numpy.zeros( (pop, nv+2) ) #
	self.vnew = numpy.zeros( nv+2 ) #

def SetLimits1( self, vmin, vmax ) :
	n = len( vmin )
	if n != self._nv :
		print( "ERROR: minima vector size is different that the number of variables" )

	n = len( vmax )
	if n != self._nv :
		print( "ERROR: maxima vector size is different that the number of variables" )

	self.Limits = numpy.zeros( (2, self._nv) )
	self.vrange = numpy.zeros( self._nv )
	i = 0
	while i < self._nv :
		self.Limits[0][i] = vmin[i]
		self.Limits[1][i] = vmax[i]
		self.vrange[i] = vmax[i] - vmin[i]
		i += 1

def EvaluatePopulation1( self ) : # Defines the function EvalutePopulation1 with no arguments
	i = 0 # Initialize i as 0
	while i<self._pop :
		v, c = evaluate.Evaluate( self._nv, self.Pop[i] )
		self.Pop[i][self._nv] = v
		self.Pop[i][self._const] = c
		i += 1 # i as a counter

def GenerateNewIndividual1( self, indice ) :
	# Generate three integer random numbers 

	r1 = numpy.random.randint( 0, self._pop-1 ) # r1 is an integer random number higher than 0 and lower than Population size - 1
	r2 = numpy.random.randint( 0, self._pop-1 ) # r2 is an integer random number higher than 0 and lower than Population size - 1
	while r2==r1 :
		r2 = numpy.random.randint( 0, self._pop-1 )

	r3 = numpy.random.randint( 0, self._pop-1 )
	while r3==r1 or r3==r2 :
		r3 = numpy.random.randint( 0, self._pop-1 )


	irand = numpy.random.randint( 0, self._nv )

	i = 0
	# Generate the new individual
	while i < self._nv :
		if numpy.random.random() < self._cr or i==irand :
			d = self._cf*( self.Pop[r1][i] - self.Pop[r2][i] )
			self.vnew[i] = self.Pop[r3][i] + d

			# checar los límites
			if self.vnew[i] < self.Limits[0][i] :
				n = self.Limits[0][i] + numpy.random.random() * self.vrange[i]
				self.vnew[i] = n
	
			if self.vnew[i] > self.Limits[1][i] :
				n = self.Limits[0][i] + numpy.random.random() * self.vrange[i]
				self.vnew[i] = n
		else :
			self.vnew[i] = self.Pop[indice][i]

		i += 1
	
# Differntial Evolution class
class DE:
	def __init__( self ) :
		self._pop = 0   # Population size
		self._gen = 1   # Number of generations
		self._nv = 0    # Number of variables
		self._cf = 0.5  # Diferences constant
		self._cr = 1.0  # Recombination constant

	SetParameters = SetParameters1 
	SetLimits = SetLimits1 
	Initialize =  Initialize1
	EvaluatePopulation = EvaluatePopulation1
	GenerateNewIndividual = GenerateNewIndividual1

	def EvaluateNewIndividual( self ) :
		self.vnew[self._nv], self.vnew[self._const] = evaluate.Evaluate( self._nv, self.vnew )
		if self.vnew[self._const] < 0.0 :
			self.vnew[self._nv] = - self.vnew[self._const]

	def CompareNewIndividual( self, indice ) :
		# Check of both are feasible
		i = self._const
		if self.vnew[i] >=0 and self.Pop[indice][i] >= 0 :
			i = self._nv
			if self.vnew[i] < self.Pop[indice][i] :
				pass
			else :
				return

		elif self.vnew[i] >=0 :
			pass

		elif self.Pop[indice][i] >= 0:
			return

		elif self.vnew[i] > self.Pop[indice][i] :	
			pass

		j = 0
		while j<=self._const :
			self.Pop[indice][j] = self.vnew[j]
			j += 1


	def PrintBest( self ) :
		v = self._nv
		miminimo = self.Pop[0][v]
		k = 0
		i = 1
		while i < self._pop :
			if self.Pop[i][v] < miminimo :
				miminimo = self.Pop[i][v]	
				k = i
			i += 1

		i = 0
		while i <= v :
			print( self.Pop[k][i], end=' ' )
			i += 1
		print( )
		# print self.Pop[k]
